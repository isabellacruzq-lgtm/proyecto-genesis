# Proyecto Genesis — Breaze in the Moon

## Descripción
Plataforma que permite a usuarios consumir operaciones de cómputo de forma controlada y con trazabilidad de costos mediante un sistema de tokens.

---

## Requisitos previos
- Java 17+
- Maven 3.8+
- MySQL 8.0+

---

## Configuración

### Variables de entorno
| Variable | Descripción | Valor por defecto |
|---|---|---|
| `DB_USERNAME` | Usuario de MySQL | `root` |
| `DB_PASSWORD` | Contraseña de MySQL | `root` |
| `JWT_SECRET` | Clave secreta para firmar JWT (mín. 256 bits) | Ver `application.properties` |
| `JWT_EXPIRATION` | Duración del token en ms | `86400000` (24h) |

### Base de datos
```bash
mysql -u root -p < init.sql
```

---

## Levantar el proyecto
```bash
# Clonar y entrar al directorio
git clone <url-del-repo>
cd genesis

# Compilar y ejecutar
mvn spring-boot:run
```

La API quedará disponible en: `http://localhost:8080`  
Swagger UI: `http://localhost:8080/swagger-ui.html`

---

## Credenciales del administrador inicial
| Campo | Valor |
|---|---|
| Email | `admin@breaze.com` |
| Contraseña | `Admin123!` |

> Generadas automáticamente al arrancar la aplicación por primera vez.

---

## Estructura del proyecto
```
src/main/java/com/breaze/genesis/
├── config/          # Configuración Spring, DataSeeder
├── controller/      # Controladores REST (solo HTTP)
├── dto/
│   ├── request/     # Modelos de entrada
│   └── response/    # Modelos de salida
├── entity/          # Entidades JPA
├── exception/       # Manejo global de errores
├── repository/      # Acceso a datos (Spring Data JPA)
└── service/
    ├── impl/        # Implementaciones de servicios
    └── operation/   # Interfaz Operation + 4 implementaciones
```

---

## Principios SOLID aplicados

### SRP — Responsabilidad Única
Cada clase tiene una única razón para cambiar: `TokenCalculator` solo calcula tokens, `OperationRegistry` solo resuelve qué operación ejecutar, cada `Operation` solo implementa su fórmula matemática.

### OCP — Abierto/Cerrado
Para añadir una **OP-05**, se crea una nueva clase que implemente `Operation` y se anota con `@Component`. `OperationRegistry` la detecta automáticamente vía Spring sin modificar ninguna clase existente.

### LSP — Sustitución de Liskov
Todas las implementaciones de `Operation` son intercambiables. `OperationServiceImpl` las trata de forma uniforme sin saber cuál es cuál.

### ISP — Segregación de Interfaces
`OperationService` y `TransactionService` son interfaces específicas y cohesivas. Los controladores dependen solo de lo que necesitan.

### DIP — Inversión de Dependencias
Los controladores dependen de interfaces (`OperationService`, `TransactionService`), no de implementaciones. `OperationRegistry` depende de la abstracción `Operation`, no de clases concretas.

---

## Rama Gitflow
`feature/operaciones-y-tokens`
