package com.breaze.genesis.controller;

import com.breaze.genesis.dto.response.ApiResponse;
import com.breaze.genesis.dto.response.MetricsResponse;
import com.breaze.genesis.dto.response.TransactionResponse;
import com.breaze.genesis.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Transacciones", description = "Historial de consumo y métricas")
@SecurityRequirement(name = "bearerAuth")
public class TransactionController {

    private final TransactionService transactionService;

    /**
     * GET /api/v1/transactions
     * Historial paginado del usuario autenticado.
     */
    @GetMapping("/transactions")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @Operation(summary = "Consultar historial de transacciones propias")
    public ResponseEntity<ApiResponse<Page<TransactionResponse>>> getHistory(
            @AuthenticationPrincipal UserDetails userDetails,
            Pageable pageable) {

        Long userId = extractUserId(userDetails);
        return ResponseEntity.ok(ApiResponse.ok(
                transactionService.getUserHistory(userId, pageable),
                "Historial de transacciones"));
    }

    /**
     * GET /api/v1/admin/metrics
     * Métricas globales de consumo (solo admin).
     */
    @GetMapping("/admin/metrics")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Métricas globales de consumo (admin)")
    public ResponseEntity<ApiResponse<MetricsResponse>> getMetrics(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(defaultValue = "5") int topN) {

        return ResponseEntity.ok(ApiResponse.ok(
                transactionService.getGlobalMetrics(from, to, topN),
                "Métricas globales"));
    }

    private Long extractUserId(UserDetails userDetails) {
        try {
            return Long.parseLong(userDetails.getUsername());
        } catch (NumberFormatException e) {
            throw new IllegalStateException(
                    "No se pudo extraer el userId del token. Coordinar con el equipo de autenticación.");
        }
    }
}
