package com.breaze.genesis.service;

import com.breaze.genesis.dto.response.TransactionResponse;
import com.breaze.genesis.dto.response.MetricsResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Contrato del servicio de transacciones e historial.
 */
public interface TransactionService {

    /**
     * Historial de transacciones del usuario autenticado (paginado).
     */
    Page<TransactionResponse> getUserHistory(Long userId, Pageable pageable);

    /**
     * Métricas globales de consumo para el administrador.
     */
    MetricsResponse getGlobalMetrics(String from, String to, int topN);
}
