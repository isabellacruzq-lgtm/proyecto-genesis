package com.breaze.genesis.controller;

import com.breaze.genesis.dto.request.ExecuteOperationRequest;
import com.breaze.genesis.dto.response.ApiResponse;
import com.breaze.genesis.dto.response.CatalogOperationResponse;
import com.breaze.genesis.dto.response.ExecuteOperationResponse;
import com.breaze.genesis.service.OperationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador de operaciones del catálogo.
 *
 * PRINCIPIO SRP: solo maneja HTTP — no contiene lógica de negocio.
 * PRINCIPIO DIP: depende de la interfaz OperationService.
 */
@RestController
@RequestMapping("/api/v1/operations")
@RequiredArgsConstructor
@Tag(name = "Operaciones", description = "Catálogo y ejecución de operaciones")
@SecurityRequirement(name = "bearerAuth")
public class OperationController {

    private final OperationService operationService;

    /**
     * GET /api/v1/operations/catalog
     * Catálogo de operaciones activas (usuario final).
     */
    @GetMapping("/catalog")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @Operation(summary = "Consultar catálogo de operaciones activas")
    public ResponseEntity<ApiResponse<List<CatalogOperationResponse>>> getCatalog() {
        return ResponseEntity.ok(ApiResponse.ok(
                operationService.getActiveCatalog(),
                "Catálogo de operaciones"));
    }

    /**
     * GET /api/v1/operations/catalog/all  (admin)
     */
    @GetMapping("/catalog/all")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Consultar catálogo completo (admin)")
    public ResponseEntity<ApiResponse<Page<CatalogOperationResponse>>> getFullCatalog(Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.ok(
                operationService.getFullCatalog(pageable),
                "Catálogo completo"));
    }

    /**
     * POST /api/v1/operations/{code}/execute
     * Ejecuta una operación y descuenta tokens al usuario autenticado.
     */
    @PostMapping("/{code}/execute")
    @PreAuthorize("hasRole('USER')")
    @Operation(summary = "Ejecutar una operación del catálogo")
    public ResponseEntity<ApiResponse<ExecuteOperationResponse>> execute(
            @PathVariable String code,
            @Valid @RequestBody ExecuteOperationRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = extractUserId(userDetails);
        ExecuteOperationResponse result = operationService.execute(code, request, userId);
        return ResponseEntity.ok(ApiResponse.ok(result, "Operación ejecutada exitosamente"));
    }

    /**
     * PATCH /api/v1/operations/{id}/toggle  (admin)
     * Activa o desactiva una operación del catálogo.
     */
    @PatchMapping("/{id}/toggle")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Activar o desactivar una operación (admin)")
    public ResponseEntity<ApiResponse<CatalogOperationResponse>> toggle(
            @PathVariable Long id,
            @RequestParam boolean active) {

        return ResponseEntity.ok(ApiResponse.ok(
                operationService.toggleOperation(id, active),
                active ? "Operación activada" : "Operación desactivada"));
    }

    // ─── Helper ───────────────────────────────────────────────────────────────

    /**
     * Extrae el userId del UserDetails. El equipo de autenticación debe almacenar
     * el id como username o proveer un UserDetails extendido.
     * Aquí se asume que el username es el email y se resuelve via UserRepository,
     * o que se usa un CustomUserDetails que expone getId().
     */
    private Long extractUserId(UserDetails userDetails) {
        // Si el equipo de auth usa un CustomUserDetails con getId():
        // return ((CustomUserDetails) userDetails).getId();
        //
        // Por ahora parseamos desde el subject si es un id numérico,
        // o el equipo de auth puede cambiar esto al integrar.
        try {
            return Long.parseLong(userDetails.getUsername());
        } catch (NumberFormatException e) {
            throw new IllegalStateException(
                    "No se pudo extraer el userId del token. Coordinar con el equipo de autenticación.");
        }
    }
}
