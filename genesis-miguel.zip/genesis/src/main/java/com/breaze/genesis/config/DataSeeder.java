package com.breaze.genesis.config;

import com.breaze.genesis.entity.CatalogOperation;
import com.breaze.genesis.entity.ExchangeRate;
import com.breaze.genesis.entity.Plan;
import com.breaze.genesis.entity.User;
import com.breaze.genesis.repository.CatalogOperationRepository;
import com.breaze.genesis.repository.ExchangeRateRepository;
import com.breaze.genesis.repository.UserRepository;
import com.breaze.genesis.repository.PlanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * Carga datos base al arrancar la aplicación.
 * Es idempotente: solo inserta si los registros no existen.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements ApplicationRunner {

    private final CatalogOperationRepository catalogOperationRepository;
    private final ExchangeRateRepository     exchangeRateRepository;
    private final PlanRepository             planRepository;
    private final UserRepository             userRepository;
    private final PasswordEncoder            passwordEncoder;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        seedPlans();
        seedOperations();
        seedExchangeRate();
        seedAdminUser();
    }

    private void seedPlans() {
        List<Object[]> planes = List.of(
            new Object[]{"Free",       200,  "Plan gratuito con 200 tokens"},
            new Object[]{"Pro",        1000, "Plan profesional con 1.000 tokens"},
            new Object[]{"Enterprise", 5000, "Plan empresarial con 5.000 tokens"}
        );
        for (Object[] p : planes) {
            String name = (String) p[0];
            if (planRepository.findByName(name).isEmpty()) {
                planRepository.save(Plan.builder()
                        .name(name)
                        .tokensGranted((Integer) p[1])
                        .description((String) p[2])
                        .active(true)
                        .build());
                log.info("Plan '{}' creado.", name);
            }
        }
    }

    private void seedOperations() {
        List<Object[]> ops = List.of(
            new Object[]{"OP-01", "¿Cuánto me cuesta ese crédito?",  "Calcula cuota, total e intereses de un crédito",       50},
            new Object[]{"OP-02", "Conversor COP ↔ USD",             "Convierte entre pesos colombianos y dólares",           20},
            new Object[]{"OP-03", "Calculadora de IMC",              "Calcula el Índice de Masa Corporal y categoría",        15},
            new Object[]{"OP-04", "Calculadora de sueño",            "Sugiere horarios óptimos para dormir o despertar",      20}
        );
        for (Object[] op : ops) {
            String code = (String) op[0];
            if (catalogOperationRepository.findByCode(code).isEmpty()) {
                catalogOperationRepository.save(CatalogOperation.builder()
                        .code(code)
                        .name((String) op[1])
                        .description((String) op[2])
                        .baseCost((Integer) op[3])
                        .active(true)
                        .build());
                log.info("Operación '{}' registrada.", code);
            }
        }
    }

    private void seedExchangeRate() {
        if (exchangeRateRepository.findTopByOrderByUpdatedAtDesc().isEmpty()) {
            exchangeRateRepository.save(ExchangeRate.builder()
                    .copPerUsd(new BigDecimal("4200.00"))
                    .build());
            log.info("Tasa de cambio inicial COP/USD = 4200 registrada.");
        }
    }

    private void seedAdminUser() {
        String adminEmail = "admin@breaze.com";
        if (userRepository.findByEmail(adminEmail).isEmpty()) {
            userRepository.save(User.builder()
                    .email(adminEmail)
                    .password(passwordEncoder.encode("Admin123!"))
                    .name("Administrador Genesis")
                    .role(User.Role.ADMIN)
                    .tokenBalance(0)
                    .active(true)
                    .build());
            log.info("Usuario administrador creado: {} / Admin123!", adminEmail);
        }
    }
}
